package hotel;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        CustomerTest.class,
        LoginClassTest.class
})
public class TestSuite {

}
